module.exports = require('./lib/yeepay');
